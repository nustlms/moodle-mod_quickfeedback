QUICK INSTALL
=============

For the impatient, here is a basic outline of the
installation process, which normally takes me only
a few minutes:

1) Move the quickfeedback folder into your mod folder.
2) Install this plugin by logging in from admin account


Good luck and have fun!
Hina Yousuf

